create table regioes(
	id serial,
	nome varchar(100) not null,
	constraint pk_regioes primary key(id)
);

create table cidades(
	id serial,
	nome varchar(100) not null,
	estado char(2) not null,
	regiao_id int not null,
	constraint pk_cidades primary key(id),
	constraint fk_cidades_regioes
		foreign key(regiao_id)
			references regioes(id)
);

create table usuarios(
	id serial,
	nome varchar(100) not null,
	email varchar(150) not null,
	login varchar(50) not null,
	senha varchar(50) not null,
	perfil varchar(20) not null,
	data_cadastro date not null,
	constraint pk_usuarios primary key(id)
);

create table doadores(
	id serial,
	usuario_id int not null,
	cpf varchar(11) not null,
	telefone varchar(15) not null,
	data_nascimento date not null,
	cidade_id int not null,
	constraint pk_doadores primary key(id),
	constraint fk_doadores_usuarios
		foreign key(usuario_id)
			references usuarios(id)
			on delete cascade,
	constraint fk_doadores_cidades
		foreign key(cidade_id)
			references cidades(id)
);

create table entidades(
	id serial,
	usuario_id int not null,
	nome varchar(150) not null,
	cnpj varchar(14) not null,
	tipo varchar(50) not null,
	telefone varchar(15) not null,
	endereco varchar(150) not null,
	situacao varchar(20) not null,
	cidade_id int not null,
	constraint pk_entidades primary key(id),
	constraint fk_entidades_usuarios
		foreign key(usuario_id)
			references usuarios(id)
			on delete cascade,
	constraint fk_entidades_cidades
		foreign key(cidade_id)
			references cidades(id)
);

create table categorias(
	id serial,
	nome varchar(100) not null,
	descricao text null,
	constraint pk_categorias primary key(id)
);

create table itens(
	id serial,
	nome varchar(100) not null,
	unidade varchar(20) not null,
	categoria_id int not null,
	constraint pk_itens primary key(id),
	constraint fk_itens_categorias
		foreign key(categoria_id)
			references categorias(id)
);

create table necessidades(
	id serial,
	entidade_id int not null,
	descricao text not null,
	urgencia varchar(20) not null,
	data_publicacao date not null,
	situacao varchar(20) not null,
	constraint pk_necessidades primary key(id),
	constraint fk_necessidades_entidades
		foreign key(entidade_id)
			references entidades(id)
			on delete cascade
);

create table necessidades_itens(
	necessidade_id int,
	item_id int,
	quantidade int not null,
	constraint pk_necessidades_itens
		primary key(necessidade_id, item_id),
	constraint fk_necessidades_itens_necessidades
		foreign key(necessidade_id)
			references necessidades(id)
			on delete cascade,
	constraint fk_necessidades_itens_itens
		foreign key(item_id)
			references itens(id)
			on delete cascade
);

create table tipos_desastres(
	id serial,
	nome varchar(100) not null,
	descricao text null,
	constraint pk_tipos_desastres primary key(id)
);

create table campanhas(
	id serial,
	titulo varchar(150) not null,
	descricao text not null,
	data_inicio date not null,
	data_fim date not null,
	situacao varchar(20) not null,
	usuario_id int not null,
	cidade_id int not null,
	tipo_desastre_id int null,
	constraint pk_campanhas primary key(id),
	constraint fk_campanhas_usuarios
		foreign key(usuario_id)
			references usuarios(id),
	constraint fk_campanhas_cidades
		foreign key(cidade_id)
			references cidades(id),
	constraint fk_campanhas_tipos_desastres
		foreign key(tipo_desastre_id)
			references tipos_desastres(id)
);

create table campanhas_entidades(
	campanha_id int,
	entidade_id int,
	constraint pk_campanhas_entidades
		primary key(campanha_id, entidade_id),
	constraint fk_campanhas_entidades_campanhas
		foreign key(campanha_id)
			references campanhas(id)
			on delete cascade,
	constraint fk_campanhas_entidades_entidades
		foreign key(entidade_id)
			references entidades(id)
			on delete cascade
);

create table doacoes(
	id serial,
	doador_id int not null,
	entidade_id int not null,
	campanha_id int null,
	data_intencao date not null,
	data_recebimento date null,
	situacao varchar(20) not null,
	constraint pk_doacoes primary key(id),
	constraint fk_doacoes_doadores
		foreign key(doador_id)
			references doadores(id)
			on delete cascade,
	constraint fk_doacoes_entidades
		foreign key(entidade_id)
			references entidades(id)
			on delete cascade,
	constraint fk_doacoes_campanhas
		foreign key(campanha_id)
			references campanhas(id)
);

create table doacoes_itens(
	doacao_id int,
	item_id int,
	quantidade int not null,
	constraint pk_doacoes_itens
		primary key(doacao_id, item_id),
	constraint fk_doacoes_itens_doacoes
		foreign key(doacao_id)
			references doacoes(id)
			on delete cascade,
	constraint fk_doacoes_itens_itens
		foreign key(item_id)
			references itens(id)
			on delete cascade
);

create or replace function gerar_cpf()
returns text as $$
declare
    n int[];
    i int;
    soma int;
    d1 int;
    d2 int;
begin
    n := array(select floor(random()*10)::int from generate_series(1,9));
    soma := 0;
    for i in 1..9 loop
        soma := soma + n[i] * (11 - i);
    end loop;
    d1 := (soma * 10 % 11);
    if d1 = 10 then d1 := 0; end if;
    soma := 0;
    for i in 1..9 loop
        soma := soma + n[i] * (12 - i);
    end loop;
    soma := soma + d1 * 2;
    d2 := (soma * 10 % 11);
    if d2 = 10 then d2 := 0; end if;
    return array_to_string(n, '') || d1 || d2;
end;
$$ language plpgsql;

create or replace function gerar_nome_completo()
returns text
language sql
as $$
  with nomes as (
	select array[
	  'João','Maria','Pedro','Ana','Lucas','Juliana','Carlos','Fernanda',
	  'Rafael','Camila','Bruno','Patrícia','Gabriel','Amanda','Felipe','Larissa',
	  'Marcos','Beatriz','Gustavo','Aline','Rodrigo','Tatiane','Eduardo','Vanessa',
	  'Diego','Renata','Leonardo','Carla','Thiago','Priscila','Vinicius','Sandra',
	  'André','Bianca','Ricardo','Daniela','Fernando','Natália','Roberto','Paula',
	  'Alexandre','Letícia','Marcelo','Cristina','Henrique','Isabela','Matheus','Luana',
	  'Igor','Bruna','Fábio','Jéssica','Danilo','Michele','Vitor','Caio',
	  'Samuel','Monique','Murilo','Cláudia','Adriano','Tatiana','Wesley','Elaine',
	  'Leandro','Raquel','Otávio','Simone','Douglas','Flávia','Hugo','Rita',
	  'Arthur','Helena','Miguel','Sofia','Davi','Laura','Heitor','Manuela'
	] as lista
  ),
  sobrenomes as (
	select array[
	  'Silva','Santos','Oliveira','Souza','Rodrigues','Ferreira','Almeida','Costa',
	  'Gomes','Martins','Rocha','Dias','Barbosa','Ribeiro','Carvalho','Alves',
	  'Pereira','Lima','Araújo','Fernandes','Castro','Nunes','Teixeira','Moreira',
	  'Correia','Mendes','Cardoso','Ramos','Machado','Freitas','Cavalcanti','Monteiro',
	  'Batista','Campos','Vasconcelos','Peixoto','Farias','Pinto','Moura','Vieira',
	  'Cunha','Neves','Rezende','Duarte','Siqueira','Tavares','Borges','Azevedo',
	  'Guimarães','Melo','Fonseca','Sales','Amaral','Coelho','Barros','Lopes'
	] as lista
  )
  select
    nomes.lista[ceil(random()*array_length(nomes.lista,1))] || ' ' ||
    sobrenomes.lista[ceil(random()*array_length(sobrenomes.lista,1))]
  from nomes, sobrenomes;
$$;

ALTER FUNCTION gerar_nome_completo() VOLATILE;
