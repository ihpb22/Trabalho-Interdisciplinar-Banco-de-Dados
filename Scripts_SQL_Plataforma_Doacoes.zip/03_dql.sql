with solicitado as (
  select
    i.categoria_id,
    sum(ni.quantidade) as quantidade
  from necessidades n
  join necessidades_itens ni on ni.necessidade_id = n.id
  join itens i on i.id = ni.item_id
  group by i.categoria_id
),
recebido as (
  select
    i.categoria_id,
    sum(di.quantidade) as quantidade
  from doacoes d
  join doacoes_itens di on di.doacao_id = d.id
  join itens i on i.id = di.item_id
  where d.situacao = 'Recebida'
  group by i.categoria_id
)
select
  c.nome as categoria,
  s.quantidade as solicitado,
  r.quantidade as recebido,
  round(r.quantidade * 100.0 / s.quantidade, 1) as cobertura_percentual
from categorias c
join solicitado s on s.categoria_id = c.id
join recebido r on r.categoria_id = c.id
order by cobertura_percentual desc;

select
  r.nome as regiao,
  count(distinct e.id) as entidades,
  count(distinct d.doador_id) as doadores,
  count(d.id) as doacoes_recebidas,
  round(count(d.id) * 1.0 / count(distinct e.id), 1) as doacoes_por_entidade
from regioes r
join cidades c on c.regiao_id = r.id
join entidades e on e.cidade_id = c.id
join doacoes d on d.entidade_id = e.id
where d.situacao = 'Recebida'
group by r.nome
order by doacoes_recebidas desc;

select
  e.tipo as tipo_entidade,
  count(d.id) as total_doacoes,
  sum(case when d.situacao = 'Recebida' then 1 else 0 end) as recebidas,
  sum(case when d.situacao = 'Pendente' then 1 else 0 end) as pendentes,
  sum(case when d.situacao = 'Cancelada' then 1 else 0 end) as canceladas,
  round(sum(case when d.situacao = 'Recebida' then 1 else 0 end) * 100.0 / count(d.id), 1) as efetivacao_percentual
from entidades e
join doacoes d on d.entidade_id = e.id
group by e.tipo
order by efetivacao_percentual desc;
