DO $$
DECLARE
	qtd_doadores INTEGER := 12000;
	qtd_entidades INTEGER := 600;
	qtd_necessidades INTEGER := 6000;
	qtd_necessidades_itens INTEGER := 18000;
	qtd_campanhas INTEGER := 300;
	qtd_campanhas_entidades INTEGER := 900;
	qtd_doacoes INTEGER := 45000;
	qtd_doacoes_itens INTEGER := 70000;
BEGIN

RAISE NOTICE '[ETAPA 01] - Iniciando os inserts na tabela regioes';
insert into regioes (nome)
values
('Metropolitana'),
('Central Serrana'),
('Sudoeste Serrana'),
('Litoral Sul'),
('Central Sul'),
('Caparaó'),
('Rio Doce'),
('Centro-Oeste'),
('Nordeste'),
('Noroeste');
RAISE NOTICE '[ETAPA 01] - Finalizado os inserts na tabela regioes';

RAISE NOTICE '[ETAPA 02] - Iniciando os inserts na tabela cidades';
insert into cidades (nome, estado, regiao_id)
values
('Vitória', 'ES', 1),
('Vila Velha', 'ES', 1),
('Serra', 'ES', 1),
('Cariacica', 'ES', 1),
('Viana', 'ES', 1),
('Guarapari', 'ES', 1),
('Fundão', 'ES', 1),
('Santa Teresa', 'ES', 2),
('Santa Maria de Jetibá', 'ES', 2),
('Itaguaçu', 'ES', 2),
('Domingos Martins', 'ES', 3),
('Venda Nova do Imigrante', 'ES', 3),
('Afonso Cláudio', 'ES', 3),
('Marechal Floriano', 'ES', 3),
('Anchieta', 'ES', 4),
('Piúma', 'ES', 4),
('Itapemirim', 'ES', 4),
('Marataízes', 'ES', 4),
('Cachoeiro de Itapemirim', 'ES', 5),
('Castelo', 'ES', 5),
('Mimoso do Sul', 'ES', 5),
('Alegre', 'ES', 6),
('Guaçuí', 'ES', 6),
('Iúna', 'ES', 6),
('Linhares', 'ES', 7),
('Aracruz', 'ES', 7),
('Sooretama', 'ES', 7),
('Colatina', 'ES', 8),
('Baixo Guandu', 'ES', 8),
('Pancas', 'ES', 8),
('São Mateus', 'ES', 9),
('Conceição da Barra', 'ES', 9),
('Pedro Canário', 'ES', 9),
('Nova Venécia', 'ES', 10),
('Barra de São Francisco', 'ES', 10),
('Ecoporanga', 'ES', 10);
RAISE NOTICE '[ETAPA 02] - Finalizado os inserts na tabela cidades';

RAISE NOTICE '[ETAPA 03] - Iniciando os inserts na tabela categorias';
insert into categorias (nome, descricao)
values
('Alimentos', 'Alimentos não perecíveis e cestas básicas'),
('Água', 'Água potável e mineral'),
('Higiene', 'Produtos de higiene pessoal'),
('Limpeza', 'Produtos de limpeza doméstica'),
('Roupas', 'Roupas, calçados e agasalhos'),
('Cama e Banho', 'Cobertores, colchões, lençóis e toalhas'),
('Medicamentos', 'Medicamentos básicos e primeiros socorros'),
('Infantil', 'Fraldas, leite e itens para bebês');
RAISE NOTICE '[ETAPA 03] - Finalizado os inserts na tabela categorias';

RAISE NOTICE '[ETAPA 04] - Iniciando os inserts na tabela itens';
insert into itens (nome, unidade, categoria_id)
values
('Cesta básica', 'unidade', 1),
('Arroz 5 kg', 'pacote', 1),
('Feijão 1 kg', 'pacote', 1),
('Macarrão 500 g', 'pacote', 1),
('Óleo de soja', 'litro', 1),
('Leite em pó', 'lata', 1),
('Água mineral 1,5 L', 'garrafa', 2),
('Água mineral 5 L', 'galão', 2),
('Água mineral 20 L', 'galão', 2),
('Sabonete', 'unidade', 3),
('Creme dental', 'unidade', 3),
('Escova de dente', 'unidade', 3),
('Absorvente', 'pacote', 3),
('Papel higiênico', 'pacote', 3),
('Kit higiene', 'kit', 3),
('Água sanitária', 'litro', 4),
('Detergente', 'unidade', 4),
('Sabão em pó', 'caixa', 4),
('Kit limpeza', 'kit', 4),
('Agasalho', 'peça', 5),
('Calça', 'peça', 5),
('Camiseta', 'peça', 5),
('Calçado', 'par', 5),
('Cobertor', 'unidade', 6),
('Colchão', 'unidade', 6),
('Lençol', 'unidade', 6),
('Toalha de banho', 'unidade', 6),
('Analgésico', 'caixa', 7),
('Soro fisiológico', 'unidade', 7),
('Kit primeiros socorros', 'kit', 7),
('Fralda infantil', 'pacote', 8),
('Fralda geriátrica', 'pacote', 8),
('Leite infantil', 'lata', 8),
('Lenço umedecido', 'pacote', 8);
RAISE NOTICE '[ETAPA 04] - Finalizado os inserts na tabela itens';

RAISE NOTICE '[ETAPA 05] - Iniciando os inserts na tabela tipos_desastres';
insert into tipos_desastres (nome, descricao)
values
('Enchente', 'Elevação do nível de rios e alagamentos'),
('Deslizamento', 'Movimento de massa em encostas'),
('Vendaval', 'Ventos fortes com destelhamentos'),
('Estiagem', 'Período prolongado sem chuvas'),
('Incêndio', 'Incêndio urbano ou florestal'),
('Granizo', 'Precipitação de gelo com danos a moradias');
RAISE NOTICE '[ETAPA 05] - Finalizado os inserts na tabela tipos_desastres';

RAISE NOTICE '[ETAPA 06] - Iniciando os inserts dos usuarios de demonstracao';
insert into usuarios (nome, email, login, senha, perfil, data_cadastro)
values
('Doador Demonstração', 'doador@doacoes.org', 'doador', 'doa#2026', 'Doador', date '2024-01-01'),
('Entidade Demonstração', 'entidade@doacoes.org', 'entidade', 'ent!2026', 'Entidade', date '2024-01-01'),
('Defesa Civil Estadual', 'defesacivil@doacoes.org', 'defesacivil', 'dc$-2026', 'Defesa Civil', date '2024-01-01'),
('Administrador', 'admin@doacoes.org', 'admin', 'adm@2026', 'Administrador', date '2024-01-01');
RAISE NOTICE '[ETAPA 06] - Finalizado os inserts dos usuarios de demonstracao';

RAISE NOTICE '[ETAPA 07] - Inserindo % registros de usuarios doadores', qtd_doadores;
with provedores as (
  select array['gmail.com','outlook.com','hotmail.com','yahoo.com'] as lista
)
insert into usuarios (nome, email, login, senha, perfil, data_cadastro)
select
  split_part(nome_completo, '_', 1),
  lower(
    split_part(nome_completo, ' ', 1) || '.' ||
    split_part(split_part(nome_completo, ' ', array_length(string_to_array(nome_completo, ' '),1)) ||
    gs, '_', 1) || gs || '@' ||
    provedores.lista[ceil(random()*array_length(provedores.lista,1))]
  ),
  'doador' || gs,
  lpad(floor(random()*100000000)::text, 8, '0'),
  'Doador',
  date '2024-01-01' + (random() * (date '2026-10-31' - date '2024-01-01'))::int
from generate_series(1, qtd_doadores) gs,
lateral (
  select gerar_nome_completo() || '_' || gs as nome_completo
) n,
provedores;
RAISE NOTICE '[ETAPA 07] - registros inseridos';

RAISE NOTICE '[ETAPA 08] - Inserindo % registros de usuarios entidades', qtd_entidades;
insert into usuarios (nome, email, login, senha, perfil, data_cadastro)
select
  split_part(nome_completo, '_', 1),
  'entidade' || gs || '@doacoes.org',
  'entidade' || gs,
  lpad(floor(random()*100000000)::text, 8, '0'),
  'Entidade',
  date '2024-01-01' + (random() * (date '2026-10-31' - date '2024-01-01'))::int
from generate_series(1, qtd_entidades) gs,
lateral (
  select gerar_nome_completo() || '_' || gs as nome_completo
) n;
RAISE NOTICE '[ETAPA 08] - registros inseridos';

RAISE NOTICE '[ETAPA 09] - Inserindo % registros na tabela doadores', qtd_doadores + 1;
insert into doadores (usuario_id, cpf, telefone, data_nascimento, cidade_id)
values
(1, gerar_cpf(), '27999990001', date '1990-05-10', 1);
insert into doadores (usuario_id, cpf, telefone, data_nascimento, cidade_id)
select
  gs + 4,
  gerar_cpf(),
  '27' || lpad(floor(random()*1000000000)::text, 9, '0'),
  date '1950-01-01' + (random() * (date '2007-12-31' - date '1950-01-01'))::int,
  floor(random() * (SELECT count(*) FROM cidades) + 1)::int
from generate_series(1, qtd_doadores) gs;
RAISE NOTICE '[ETAPA 09] - registros inseridos';

RAISE NOTICE '[ETAPA 10] - Inserindo % registros na tabela entidades', qtd_entidades + 1;
insert into entidades (usuario_id, nome, cnpj, tipo, telefone, endereco, situacao, cidade_id)
values
(2, 'Associação Solidária Demonstração', '12345678000190', 'ONG', '2733330001', 'Rua da Solidariedade, 100', 'Aprovada', 1);
insert into entidades (usuario_id, nome, cnpj, tipo, telefone, endereco, situacao, cidade_id)
select
  gs + 4 + qtd_doadores,
  (ARRAY['Associação','Instituto','Casa de Apoio','Projeto','Abrigo','Banco de Alimentos'])[floor(random()*6 + 1)]
  || ' '
  || (ARRAY['Esperança','Solidariedade','Vida Nova','Mãos Unidas','Bom Samaritano','Recomeço','Acolher','Semear'])[floor(random()*8 + 1)]
  || ' ' || gs,
  lpad(floor(random()*100000000)::text, 8, '0') || '0001' || lpad(floor(random()*100)::text, 2, '0'),
  (ARRAY['ONG','Abrigo','Igreja','Associação de Moradores','Banco de Alimentos','Instituição de Acolhimento'])[floor(random()*6 + 1)],
  '27' || lpad(floor(random()*100000000)::text, 8, '0'),
  (ARRAY['Rua','Avenida','Travessa'])[floor(random()*3 + 1)]
  || ' '
  || (ARRAY['das Flores','Central','São José','Brasil','da Paz','Santos Dumont','Getúlio Vargas','Beira Rio'])[floor(random()*8 + 1)]
  || ', ' || floor(random()*2000 + 1)::int,
  CASE
    WHEN (SELECT floor(random() * 100 + 1)::int > 5) THEN 'Aprovada'
    ELSE 'Pendente'
  END,
  floor(random() * (SELECT count(*) FROM cidades) + 1)::int
from generate_series(1, qtd_entidades) gs;
RAISE NOTICE '[ETAPA 10] - registros inseridos';

RAISE NOTICE '[ETAPA 11] - Inserindo % registros na tabela necessidades', qtd_necessidades;
insert into necessidades (entidade_id, descricao, urgencia, data_publicacao, situacao)
select
  floor(random() * (SELECT count(*) FROM entidades) + 1)::int,
  'Necessidade #' || gs || ' - '
  || (ARRAY['Reposição de estoque','Atendimento a famílias desabrigadas','Campanha do agasalho','Apoio a idosos','Apoio a crianças','Distribuição semanal'])[floor(random()*6 + 1)],
  (ARRAY['Baixa','Média','Alta','Crítica'])[floor(random()*4 + 1)],
  date '2024-01-01' + (random() * (date '2026-10-31' - date '2024-01-01'))::int,
  (ARRAY['Aberta','Aberta','Atendida','Atendida','Encerrada'])[floor(random()*5 + 1)]
from generate_series(1, qtd_necessidades) gs;
RAISE NOTICE '[ETAPA 11] - registros inseridos';

RAISE NOTICE '[ETAPA 12] - Inserindo % registros na tabela necessidades_itens', qtd_necessidades_itens;
insert into necessidades_itens (necessidade_id, item_id, quantidade)
select
  floor(random() * (SELECT count(*) FROM necessidades) + 1)::int,
  floor(random() * (SELECT count(*) FROM itens) + 1)::int,
  floor(random() * 100 + 1)::int
from generate_series(1, qtd_necessidades_itens) gs
ON CONFLICT DO NOTHING;
RAISE NOTICE '[ETAPA 12] - registros inseridos';

RAISE NOTICE '[ETAPA 13] - Inserindo % registros na tabela campanhas', qtd_campanhas;
insert into campanhas (titulo, descricao, data_inicio, data_fim, situacao, usuario_id, cidade_id, tipo_desastre_id)
select
  'Campanha #' || gs || ' - '
  || (ARRAY['Agasalho Solidário','Alimento para Todos','Volta às Aulas','Natal Solidário','Ajuda Humanitária','Higiene é Saúde'])[floor(random()*6 + 1)],
  'Arrecadação de itens para atendimento da população',
  date '2024-01-01' + gs * 3,
  date '2024-01-01' + gs * 3 + 30 + (random() * 60)::int,
  CASE
    WHEN date '2024-01-01' + gs * 3 + 90 < current_date THEN 'Encerrada'
    ELSE 'Ativa'
  END,
  CASE
    WHEN gs % 4 = 0 THEN 3
    ELSE 2
  END,
  floor(random() * (SELECT count(*) FROM cidades) + 1)::int,
  CASE
    WHEN gs % 4 = 0 THEN floor(random() * (SELECT count(*) FROM tipos_desastres) + 1)::int
    ELSE NULL
  END
from generate_series(1, qtd_campanhas) gs;
RAISE NOTICE '[ETAPA 13] - registros inseridos';

RAISE NOTICE '[ETAPA 14] - Inserindo % registros na tabela campanhas_entidades', qtd_campanhas_entidades;
insert into campanhas_entidades (campanha_id, entidade_id)
select
  floor(random() * (SELECT count(*) FROM campanhas) + 1)::int,
  floor(random() * (SELECT count(*) FROM entidades) + 1)::int
from generate_series(1, qtd_campanhas_entidades) gs
ON CONFLICT DO NOTHING;
RAISE NOTICE '[ETAPA 14] - registros inseridos';

RAISE NOTICE '[ETAPA 15] - Inserindo % registros na tabela doacoes', qtd_doacoes;
insert into doacoes (doador_id, entidade_id, campanha_id, data_intencao, data_recebimento, situacao)
select
  floor(random() * (SELECT count(*) FROM doadores) + 1)::int,
  floor(random() * (SELECT count(*) FROM entidades) + 1)::int,
  CASE
    WHEN random() > 0.7 THEN floor(random() * (SELECT count(*) FROM campanhas) + 1)::int
    ELSE NULL
  END,
  d.data_intencao,
  CASE
    WHEN gs % 10 < 8 THEN d.data_intencao + (random() * 10)::int
    ELSE NULL
  END,
  CASE
    WHEN gs % 10 < 8 THEN 'Recebida'
    WHEN gs % 10 = 8 THEN 'Pendente'
    ELSE 'Cancelada'
  END
from generate_series(1, qtd_doacoes) gs,
lateral (
  select gs as numero, date '2024-01-01' + (random() * (date '2026-10-21' - date '2024-01-01'))::int as data_intencao
) d;
RAISE NOTICE '[ETAPA 15] - registros inseridos';

RAISE NOTICE '[ETAPA 16] - Inserindo % registros na tabela doacoes_itens', qtd_doacoes_itens;
insert into doacoes_itens (doacao_id, item_id, quantidade)
select
  CASE
    WHEN gs <= qtd_doacoes THEN gs
    ELSE floor(random() * qtd_doacoes + 1)::int
  END,
  floor(random() * (SELECT count(*) FROM itens) + 1)::int,
  floor(random() * 20 + 1)::int
from generate_series(1, qtd_doacoes_itens) gs
ON CONFLICT DO NOTHING;
RAISE NOTICE '[ETAPA 16] - registros inseridos';

END $$;

SELECT relname AS tabela, n_live_tup AS registros
FROM pg_stat_user_tables
ORDER BY n_live_tup DESC;
